// src/pages/About.jsx
import { Typography } from "@mui/material";

export default function About() {
  return <Typography variant="h5">
                Questa è la pagina About
         </Typography>;
}
